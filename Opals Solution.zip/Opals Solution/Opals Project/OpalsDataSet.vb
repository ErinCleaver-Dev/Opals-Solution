﻿Partial Class OpalsDataSet
End Class

Namespace OpalsDataSetTableAdapters

    Partial Public Class ProductTableAdapter
    End Class
End Namespace
